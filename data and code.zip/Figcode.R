#Network-guided synthesis of antagonistic microbiome for suppressing maize stalk rot disease
#Da Li1,2, Zishuo Qu1,2, Wenzhe Feng1, Xin Zhou1*, and Lei Cai1,2*
#1State Key Laboratory of Microbial Diversity and Innovative Utilization, Institute of Microbiology, Chinese Academy of Sciences, Beijing 100101, P. R. China 
#2College of Life Science, University of Chinese Academy of Sciences, Beijing 100049, P. R. China. 
#*Corresponding author: Xin Zhou, email: zhouxin@im.ac.cn; Lei Cai, email: cail@im.ac.cn 

###########################Fig1A

da<-read.csv("Fig1A.csv")

library(ggalluvial)
library(imputeTS)

cols <- c("#f49128","#194a55","#187c65","#f26115","#c29f62","#83ba9e",
          "#c62d17","#023f75","#ea894e","#266b69","#eb4601","#f6c619")

cols <- c("#203378","#e3bf2b","#e31a1c","#1f78b4","#00B76D","#FF5900","#C5199E", "#C2855E",
          "#A4C9CC","#65472F", "#DD7694")

p1 <- ggplot(data = da,
             aes(x = State, y = Percentage, fill = group)) +
  geom_col(width = 0.7) + 
  facet_grid(~Compartment) + 
  scale_fill_manual(values = cols[1:length(unique(da$group))]) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 30,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')


p1

ggsave("Fig1A.pdf",p1,width = 6,height = 8)




#################Fig1B
bf<-rbind(b,f)
BB <-bf

BB <- BB %>% filter(
  !is.na(final_process),
  !is.na(phydist2),
  final_process != "",
  !is.na(co), !is.na(st)
)

combs <- expand.grid(
  co = c("Rhizosphere","Root","Stem","Seed"),
  st = c("Healthy","Diseased"),
  stringsAsFactors = FALSE
)

cols <- c("#203378","#e3bf2b","#e31a1c","#1f78b4","#00B76D","#FF5900","#C5199E", "#C2855E",
          "#A4C9CC","#65472F", "#DD7694")

ebtop <- function(x){ mean(x) + sd(x)/sqrt(length(x)) }
ebbottom <- function(x){ mean(x) - sd(x)/sqrt(length(x)) }
library(agricolae)
for (i in 1:nrow(combs)) {
  cur_co <- combs$co[i]
  cur_st <- combs$st[i]
  
  cat("====================================================\n")
  cat("a：", cur_co, " | ", cur_st, "\n")
  
  pl <- BB %>% filter(co == cur_co, st == cur_st)
  
  if(nrow(pl) < 5 || length(unique(pl$final_process)) < 2) {
    cat("kip \n\n")
    next
  }
  
  kw <- kruskal.test(phydist2 ~ final_process, data = pl)
  cat("Kruskal-Wallis p-value：", kw$p.value, "\n")
  
  oneway <- aov(phydist2 ~ final_process, data = pl)
  lsd_result <- LSD.test(oneway, "final_process", p.adj = "bonferroni", alpha = 0.05)
  
  sig_letter <- lsd_result$groups %>%
    rownames_to_column("final_process") %>%
    arrange(final_process) 
  
  
  mean_val <- pl %>%
    group_by(final_process) %>%
    summarise(mean_y = mean(phydist2),
              se_y = sd(phydist2)/sqrt(n()),
              .groups = "drop") %>%
    arrange(final_process)
  
  plot_label <- cbind(mean_val, sig_letter[, "groups", drop=F])
  colnames(plot_label)[ncol(plot_label)] <- "letter"
  
  p1 <- ggplot(pl, aes(x = final_process, y = phydist2, fill = final_process)) +
    
    stat_summary(geom = "bar", fun = "mean",
                 position = position_dodge(0.9), width = 0.7) +
    
    stat_summary(geom = "errorbar",
                 fun.min = ebbottom,
                 fun.max = ebtop,
                 position = position_dodge(0.9),
                 width = 0.2, size = 0.8) +
    
    geom_text(data = plot_label,
              aes(x = final_process,
                  y = mean_y + se_y + 0.1 * max(pl$phydist2), 
                  label = letter),
              inherit.aes = F, size = 6, fontface = "bold") +
    
    scale_fill_manual(values = cols) +
    
    scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
    labs(y = "Phylogenetic distance (My)", x = "") +
    
    theme_bw(base_size = 16) +
    theme(
      axis.ticks = element_line(color='black', size = 0.6),
      axis.ticks.length = unit(0.4, "lines"),
      axis.line = element_line(colour = "black", size = 0.6),
      axis.title.y = element_text(size = 20, vjust = 1.5),
      axis.text.x = element_text(size = 18, angle = 45, hjust = 1, color='black'),
      axis.text.y = element_text(size = 18, color='black'),
      legend.position = 'none'
      
    )
  
  
  filename <- paste0("B+F_", cur_co, "_", cur_st, "_phy_sig_new.pdf")
  ggsave(filename, p1, width = 5.5, height = 6.5, device = "pdf")
  
  print(p1)
  cat("ok：", filename, "\n\n")
}




library(ggplot2)
library(ggpubr)


dat_BB  <-BB 

dat_BB <- dat_BB %>%
  filter(
    !is.na(phydist2),
    !is.na(st),
    !is.na(co),
    st %in% c("Healthy", "Diseased"),
    co %in% c("Rhizosphere", "Root", "Stem", "Seed")
  )


cols_st <- c("Healthy" = "#194a55", "Diseased" = "#f49128")



plot_phydist <- function(data, process_type, save_name, ylab) {
  da <- data %>% filter(final_process == process_type)
  
  if(nrow(da) == 0) {
    message(paste0(process_type, " kip"))
    return(NULL)
  }
  
  p <- ggplot(da, aes(x = st, y = phydist2, color = st)) +
    geom_boxplot(alpha = 0.5, size = 1, outlier.shape = NA) +
    # geom_jitter(size = 0.2) +
    scale_color_manual(values = cols_st) +
    stat_compare_means(
      method = "wilcox.test", paired = FALSE,   #wilcox.test
      comparisons = list(c("Healthy", "Diseased"))
    ) +
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.1))) +
    facet_wrap(~co, ncol = 4) +
    theme_bw(base_size = 16) +
    theme(
      axis.ticks.length = unit(0.4, "lines"),
      axis.ticks = element_line(color = "black"),
      axis.line = element_line(colour = "black"),
      axis.title.x = element_text(size = 20, vjust = 1.5),
      axis.title.y = element_text(size = 20, vjust = 1.5),
      axis.text.x = element_text(size = 18, angle = 90, hjust = 1),
      axis.text.y = element_text(size = 18),
      strip.text = element_text(size = 15, face = "bold"),
      legend.position = "right"
    ) +
    labs(y = ylab, x = "")
  
  ggsave(save_name, p, width = 8, height = 4, device = "pdf")
  return(p)
}

p_pos <- plot_phydist(
  data = dat_BB,
  process_type = "positive_int",
  save_name = "B+F_Pos_phydist_ck_new.pdf",
  ylab = "CK Pos phydist"
)
p_neg <- plot_phydist(
  data = dat_BB,
  process_type = "negative_int",
  save_name = "B+F_Neg_phydist_ck_new.pdf",
  ylab = "CK Neg phydist"
)


###################################fig2B
da<-read.csv("Fig2B.csv")
head(da)
p1<-ggplot(data=da, aes(x = State, y = Degree,
                        color=State)) +
  geom_boxplot(alpha =0.5,size=1,outlier.shape = NA)+
  scale_color_manual(limits=c("Healthy","Diseased"), 
                     values=c("#194a55","#f49128"))+
  stat_compare_means(method = "wilcox.test",paired = F, 
                     comparisons=list(c("Healthy","Diseased")))+
  # geom_jitter(size=0.01)+
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.1)))+
  facet_wrap(~Compartment, ncol=4)+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 90,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Degree')
p1

ggsave("Degree.pdf",p1,width =12,height = 6)


p1<-ggplot(data=da, aes(x = State, y = Clos,
                        color=State)) +
  geom_boxplot(alpha =0.5,size=1,outlier.shape = NA)+
  scale_color_manual(limits=c("Healthy","Diseased"), 
                     values=c("#194a55","#f49128"))+
  stat_compare_means(method = "wilcox.test",paired = F, 
                     comparisons=list(c("Healthy","Diseased")))+
  #geom_jitter(size=0.2)+
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.1)))+
  facet_wrap(~Compartment, ncol=4)+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 90,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Clos Degree')
p1

ggsave("Clos Degree.pdf",p1,width =12,height = 6)


#################################Fig3

net<-read.csv("Fig3A.csv")
library(ggplot2)

p1<-ggplot(net, aes(x = Compartment, y = Link.F, fill = State)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_fill_manual(values = c("#f49128","#194a55")) +
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 90),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'null')+
  labs(y='No.link to Fusarium ')
p1


ggsave("No.link to Fusarium.pdf",p1,width = 4,height = 6)


##########################fig3B
ne<-read.csv("Fig3B.csv")
ne$weight<- -1* ne$weight
net<-ne
species <- unique(c(net$sp1, net$sp2))
num_species <- length(species)

cor_matrix <- matrix(0, nrow = num_species, ncol = num_species,
                     dimnames = list(species, species))

for (i in 1:nrow(net)) {
  species1 <- net$sp1[i]
  species2 <- net$sp2[i]
  correlation <- net$weight[i]
  
  cor_matrix[species1, species2] <- correlation
  cor_matrix[species2, species1] <- correlation
}

cor_matrix
g<-graph.adjacency(cor_matrix,weighted=TRUE,mode="undirected")
plot(g)

library(tidyverse)
library(ggplot2)
library(igraph)
library(ggraph)
library(RColorBrewer)
col<-c("#f49128","#194a55","#187c65","#f26115","#c29f62","#83ba9e","#c62d17","#023f75","#ea894e","#266b69","#eb4601","#f6c619","#f49128","#194a55","#187c65")

label_size <- 0.8
plot(g, vertex.color = col, edge.color = '#f26115', vertex.label.cex = label_size,vertex.label.dist = 3)


edge_weights <- abs(E(g)$weight) 

min_width <- 1
max_width <- 5
scaled_widths <- min_width + (max_width - min_width) * (edge_weights - min(edge_weights)) / (max(edge_weights) - min(edge_weights))
node_degrees <- degree(g)

min_size <- 10   
max_size <- 15 

scaled_sizes <- min_size + (max_size - min_size) * (node_degrees - min(node_degrees)) / (max(node_degrees) - min(node_degrees))

plot(g,
     vertex.color = col,
     vertex.size = scaled_sizes,  
     edge.color = '#f26115',
     edge.width = scaled_widths,  
     vertex.label.dist = 3,
     main = "plot")

#######################4A
a<-read.csv("4A.csv")
t<-read.csv("wtax.csv")
names(t)[1]<-c("ID")
c<-merge(a,t,by="ID")
write.csv(c,"RFtax.csv")

df<-c
df<-read.csv("RFtax.csv",row.names = 1)
df1 <- df %>% 
  arrange(desc(lncMSE)) %>%
  mutate(Genus = factor(Genus, levels = Genus))

df1 <- df %>%
  arrange(desc(lncMSE)) %>%
  mutate(Genus = factor(Genus, levels = unique(Genus)))
p<-ggplot(df1, aes(x = Genus, y = lncMSE, fill = tax)) +
  geom_bar(stat = "identity", width = 0.8, color = "black", alpha = 0.85) +
  scale_fill_manual(values = c("pro" = "#194a55", "pre" = "#f49128")) +
  labs(title = "lncMSE by Bacterial Genus",
       x = "Genus (OTU ID)",
       y = "lncMSE",
       fill = "Taxonomic Group") +
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 30),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  geom_text(aes(label = sprintf("%.1f", lncMSE)), 
            position = position_stack(vjust = 0.5),
            color = "black", size = 3)

p
ggsave("4a.pdf",p,width = 14,height = 10)

##################4B

p2<-ggplot(data=ta, aes(x = tax, y = lncMSE,
                        color=tax)) +
  geom_boxplot(alpha =0.5,size=1,outlier.shape = NA)+
  scale_color_manual(limits=c("pre","pro"), 
                     values=c("#f49128","#194a55"))+
  stat_compare_means(method = "wilcox.test",paired = F, 
                     comparisons=list(c("pre","pro")))+
  geom_jitter(size=1)+
  
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Importance (%lncMSE)')
p2

ggsave("4B.pdf",p2,width = 5,height = 6)


######################################5C
da <- da %>%
  mutate(
    Treat = factor(Treat, levels = c("Mock", "SynCom")),  
    Fu = factor(Fu, levels = c("Fv", "Fg"))              
  )

plot_data_summary <- da %>%
  group_by(Fu, Treat) %>%
  summarise(
    mean_DIndex = mean(DIndex, na.rm = TRUE), 
    se_DIndex = sd(DIndex, na.rm = TRUE) / sqrt(n()), 
    .groups = 'drop'
  )


stat_results <- da %>%
  group_by(Fu) %>%
  summarise(
    p_value = wilcox.test(DIndex ~ Treat, data = cur_data())$p.value,
    .groups = 'drop'
  ) %>%
  mutate(
 
    p_label = ifelse(p_value < 0.0000001, "P < 0.001", paste0("P = ", round(p_value, 5))),
  
    y_position = plot_data_summary %>% 
      filter(Fu == cur_data()$Fu) %>% 
      summarise(max_pos = max(mean_DIndex + se_DIndex) * 1.2) %>% 
      pull(max_pos)
  )

color_config <- c("Mock" = "#4E79A7", "SynCom" = "#76B7B2")  


jitter_colors <- color_config

p1 <- ggplot() +
  geom_col(
    data = plot_data_summary,
    aes(x = Treat, y = mean_DIndex, fill = Treat),
    width = 0.7,
    color = "black",
    size = 0.4
  ) +
  geom_errorbar(
    data = plot_data_summary,
    aes(x = Treat, ymin = mean_DIndex - se_DIndex, ymax = mean_DIndex + se_DIndex),
    width = 0.2,
    color = "black",
    size = 0.5
  ) +
  geom_jitter(
    data = da,
    aes(x = Treat, y = DIndex, color = "black"),
    size = 1.2,          
    width = 0.15,      
    height = 0,        
    show.legend = FALSE  
  ) +

  geom_text(
    data = stat_results,
    aes(x = 1.5, y = y_position, label = p_label),
    size = 5,
    fontface = "bold",
    color = "black"
  ) +
  scale_fill_manual(values = color_config, name = "Treatment") +
  scale_color_manual(values = jitter_colors, guide = "none") +  
  facet_wrap(~Fu, ncol = 2) +
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.2))) +
  theme_bw(base_size = 16) +
  theme(
    axis.ticks.length = unit(0.4, "lines"),
    axis.ticks = element_line(color = "black"),
    axis.line = element_line(colour = "black"),
    axis.title.x = element_text(colour = "black", size = 20, vjust = 1.5),
    axis.title.y = element_text(colour = "black", size = 20, vjust = 1.5),
    axis.text.y = element_text(colour = "black", size = 18),
    axis.text.x = element_text(colour = "black", size = 18, angle = 90, hjust = 1),
    strip.text = element_text(colour = "black", size = 15, face = "bold"),
    legend.position = "right",
    legend.title = element_text(size = 16, face = "bold"),
    legend.text = element_text(size = 16),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    strip.background = element_rect(fill = "grey90", colour = "black", size = 0.8)
  ) +
  labs(x = "Treatment", y = "Disease index")

print(p1)

ggsave("DIn.pdf", p1, width = 7, height = 4, dpi = 600, useDingbats = FALSE)

###############################5C
library(tibble)
x_axis_order <- c("CK", "Ran.Syn", "Net.Syn", "Ref.Net.Syn")
sci_colors <- setNames(c("#4E79A7", "#F28E2B", "#E15759", "#76B7B2"), x_axis_order)

w <- read.csv("5c.csv")
aa <- w
kruskal_result_DIndex <- kruskal.test(DIndex ~ Group, data = aa)
oneway <- aov(DIndex ~ Group, data = aa)
lab <- HSD.test(oneway, "Group", alpha = 0.05)$groups %>%
  select(-DIndex) %>%
  rownames_to_column('Group')

summary_data_DIndex <- aa %>%
  mutate(Group = factor(Group, levels = x_axis_order)) %>%
  group_by(Group) %>%
  summarise(
    mean = mean(DIndex, na.rm = TRUE),
    se = sd(DIndex, na.rm = TRUE) / sqrt(n()),
    n = n()
  ) %>%
  left_join(lab, by = "Group") %>%
  mutate(label_y = mean + se + 0.05 * (max(mean, na.rm = TRUE) - min(mean, na.rm = TRUE)))
p2 <- ggplot(summary_data_DIndex, aes(x = Group, y = mean, fill = Group)) +
  geom_bar(stat = "identity", width = 0.7, color = "black", size = 0.3) +
  geom_errorbar(aes(ymin = mean - se, ymax = mean + se), 
                width = 0.2, size = 0.5, color = "black") +
  scale_fill_manual(values = sci_colors) +
  scale_x_discrete(limits = x_axis_order) + 
  geom_text(aes(y = label_y, label = groups), 
            size = 5, vjust = -0.5) +
  annotate("text", 
           x = Inf, y = Inf, 
           label = paste("Kruskal-Wallis\nP =", 
                         format(kruskal_result_DIndex$p.value, digits = 3, scientific = TRUE)), 
           hjust = 1.1, vjust = 1.5, size = 5) +
  labs(x = 'Treatment Group', y = 'Disease Index (DIndex)') +
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 30,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'none')+
  scale_y_continuous(expand = expansion(mult = c(0, 0.15)))

print(p2)
ggsave("5c.pdf", p2, width = 6, height = 6)


#########################6B

library(ggplot2)
m1<- m[m$`%IncMSE.pval` < 0.05, ]
cols <- c("#EFF7FC", "#E0F4FEFF", "#B2E5FCFF", "#80D3F9FF", "#4EC3F7FF",
          "#28B6F6FF", "#02A9F3FF", "#029AE5FF", "#0187D1FF", "#0177BDFF",
          "#006BB3", "#00548C", "#003D66")
cols <- c("#4E79A7", "#E15759", "#33A02C", "#aebea6","#266b69", "#FDBF6F","#ea894e", "#1F78B4", "#223e9c", "#999999","#eb4601", "#A6CEE3")


m1<- m1[order(m1$MSE, decreasing = TRUE), ]

p <- ggplot(m1, aes(x = OTU_name, y = MSE, fill =  "#4E79A7")) +
  geom_col(width = 0.7, alpha = 0.8) + 
  labs(title = NULL, x = NULL, y = 'Increase in MSE (%)', fill = 'Name') +
  theme(panel.grid = element_blank(), panel.background = element_blank(), 
        axis.line = element_line(colour = 'black')) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_y_continuous(expand = c(0, 0), limit = c(0, 8)) +
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4, "lines"), 
        axis.ticks = element_line(color = 'black'),
        axis.line = element_line(colour = "black"),
        axis.title.x = element_text(colour = 'black', size = 20, vjust = 1.5),
        axis.title.y = element_text(colour = 'black', size = 20, vjust = 1.5),
        axis.text.y = element_text(colour = 'black', size = 18),
        axis.text.x = element_text(colour = 'black', size = 12, angle = 90, hjust = 1),
        strip.text = element_text(colour = "black", size = 15, face = "bold"),
        legend.position = 'right') +  
  scale_fill_manual(values = cols) 

p1 <- p +
  geom_text(data = m1, aes(x = OTU_name, y = MSE, label = sig), size = 12) +
  annotate("text", x = Inf, y = Inf, label = expression(paste("R"^2, " = 71.8%")), 
           hjust = 1.1, vjust = 1.1, size = 6, fontface = "bold", color = "black")
p1

ggsave("6b.pdf",p1,width = 10,height =4)







#######################6C

names(aa)[2]<-c("DI")
kruskal.test(DI~Group,data=aa)
head(aa)
oneway <- aov(DI ~ Group,data = aa)
lab <- LSD.test(oneway,"Group",p.adj="bonferroni", alpha = 0.05)$groups %>% 
  select(-DI) %>% 
  rownames_to_column('Group')
lab <- HSD.test(oneway,"Group",alpha = 0.05)$groups %>% 
  select(-DI) %>%  
  rownames_to_column('Group')
head(lab)
library(dplyr)
d1 <- aa %>%
  group_by(Group) %>%
  summarise(across(everything(), list(min = min, max = max))) %>%
  mutate(pos = DI_max + (max(DI_min) - min(DI_min)) * 0.2) %>%
  left_join(lab, by = "Group") %>% 
  select(Group, pos, groups)

d2 <-   
  aa %>%   
  left_join(d1) %>%   
  arrange(aa$groups) %>% 
  mutate(Group = factor(Group, levels = unique(Group), ordered = TRUE)) %>%   
  select(Group, everything())   
head(d2)

d_summary <- aa %>% 
  group_by(Group) %>% 
  summarise(Mean = mean(DI), SD = sd(DI)) %>%
  left_join(lab, by = "Group")  
d_summary$Group <- factor(d_summary$Group, levels = levels(d2$Group))

offset <- max(d_summary$SD) * 1.5
d_summary$pos <- d_summary$Mean + d_summary$SD + offset

p1 <- ggplot() +
  geom_col(data = d_summary, aes(x=Group, y=Mean, fill=Group), width=0.6) +
  geom_errorbar(data = d_summary, aes(x=Group, ymin=Mean-SD, ymax=Mean+SD), width=0.2, size=1) +
  geom_jitter(data = d2, aes(x=Group, y=DI), position=position_jitter(width=0.1), size=1.5) +
  geom_text(data = d_summary, aes(x=Group, y=pos, label=groups), size=5) +
  annotate("text", x=6, y=2, label = "Kruskal-Wallis: P = 0.0113", size=5) +
  scale_fill_manual(values = custom_colors) +
  xlab('Group') +
  ylab('R') +
  theme_classic() +
  theme(axis.text.x=element_text(angle=45, vjust=1, hjust=1),
        legend.position = 'none') +
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), 
        axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20, vjust=1.5),
        axis.title.y=element_text(colour='black', size=20, vjust=1.5),
        axis.text.y=element_text(colour='black',size=18),
        axis.text.x=element_text(colour='black',size=18, angle=60, hjust=1),
        strip.text = element_text(colour = "black", size=15, face="bold"),
        legend.position = 'null')

p1
ggsave("6c.pdf",p1,width = 8,height = 7)


############################################7A


data <- read.csv("7a.csv")
str(data)
head(data)

strain_order <- c("B267", "LDB139", "LDB271", "LDB377", "ph14", "F470", "Syn")
data$Strain <- factor(data$Strain)
data$Dif <- factor(data$Dif, levels = c("Up", "Down"))
data$Compartment <- factor(data$Compartment, levels = c("Leaf", "Root"))

p <- ggplot(data, aes(x = Strain, y = Numbers, fill = Dif)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  facet_wrap(~ Compartment, scales = "free_x", ncol = 2) +
  scale_fill_manual(values = c("Up" = "#f49128", "Down" =  "#194a55")) +
  labs(
    title = "",
    x = "Strain",
    y = "Numbers",
    fill = "Dif"
  ) +
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 30,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right') +
  geom_text(
    aes(label = Numbers),
    position = position_dodge(width = 0.8),
    vjust = -0.3, 
    size = 3
  )
print(p)

ggsave(filename = "strain_dif_barplot.pdf", plot = p,width = 10,height = 6)


##########################7B


go_data <- read.csv("7B.csv", stringsAsFactors = FALSE)

head(go_data)
str(go_data)

go_data_plot <- go_data %>%
  mutate(`-log10(FDR)` = -log10(p.adjust),  
         RichFactor = Count / as.numeric(sapply(strsplit(BgRatio, "/"), `[`, 1))) %>% 
  arrange(p.adjust) %>%  
  slice_head(n = 15)    


go_data_plot$Description <- fct_reorder(go_data_plot$Description, go_data_plot$RichFactor)

p <- ggplot(go_data_plot, 
            aes(x = RichFactor, 
                y = Description)) +
  geom_point(aes(size = Count, 
                 color = `-log10(FDR)`), 
             alpha = 0.8) + 

  scale_color_gradientn(
    colours = c("#194a55","#f49128"),
    name = expression(-log[10](FDR)), 
    limits = c(floor(min(go_data_plot$`-log10(FDR)`)), 
               ceiling(max(go_data_plot$`-log10(FDR)`))), 
    breaks = scales::pretty_breaks(n = 5) 
  ) +
  scale_size_continuous(
    name = "Gene Count",
    range = c(4, 10), 
    breaks = pretty(go_data_plot$Count, n = 3)  
  ) +
  labs(
    x = "Rich Factor", 
    y = NULL, 
    title = "GO Enrichment Analysis of Upregulated Genes\n(SynCom vs Control, Root Tissue)"
  ) +
  theme_classic(base_family = "Arial") +  
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 90,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right') +
  geom_vline(xintercept = 0, linetype = "solid", color = "grey80", linewidth = 0.3)

print(p)
ggsave(filename = "GO_Enrichment_JournalStyle_Syncoms_root.pdf",
       plot = p,
       device = cairo_pdf,  
       width = 10,          
       height = 6,        
       dpi = 600)






